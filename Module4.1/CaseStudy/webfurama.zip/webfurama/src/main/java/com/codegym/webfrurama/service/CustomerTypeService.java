package com.codegym.webfrurama.service;

import com.codegym.webfrurama.model.CustomerType;

import java.util.List;

public interface CustomerTypeService {
    List<CustomerType> findAll();
}
