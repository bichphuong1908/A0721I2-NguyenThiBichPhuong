package com.codegym.webfrurama;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfruramaApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebfruramaApplication.class, args);
    }

}
