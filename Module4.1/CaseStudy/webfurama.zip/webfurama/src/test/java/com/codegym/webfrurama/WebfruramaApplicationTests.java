package com.codegym.webfrurama;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfruramaApplicationTests {

    @Test
    void contextLoads() {
    }

}
