package com.codegym.module4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Module4Application {

    public static void main(String[] args) {
        SpringApplication.run(Module4Application.class, args);
    }

}
