package com.codygym.thi4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Thi4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
